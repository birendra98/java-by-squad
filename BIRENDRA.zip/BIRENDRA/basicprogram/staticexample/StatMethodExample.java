package staticexample;

public class StatMethodExample {
	public void insMethod1()
	{
		System.out.println("Instance method 1");
		insMethod2();			//can call instance()
		statMethod1();			// can also call static()
	}
	public void insMethod2()
	{
		System.out.println("Instance method 2");
		
	}
	
	public static void statMethod1()
	{
		statMethod2();			//can call Static() only
		//insMethod2();			//Error - Can't call Non-static
		System.out.println("Static method 1");
	}
	public static void statMethod2()
	{
		System.out.println("Static method 2");
		
	}
	public static void main(String []args)
	{
		statMethod1();				//Directly call Static()
		StatMethodExample obj = new StatMethodExample();  //Need obj to call instance()
		obj.insMethod2();
	}
	

}
