package staticexample;

public class StatVarExample {
	int a = 10; 	// NON-STATIC = Instance
	static int b =20;		//STATIC = Class
	
	public void instMethod()
	{
		System.out.println(a);			// Can call Instance members(variable/methods)
		System.out.println(b);			// Can call Static members(variable/methods)
	}
	public static void statMethod()
	{
		//System.out.println(a);		//ERROR - Can't call any non-static member
		System.out.println(b);			// Can call Static members(variable/methods)
	}
	public static void main(String []args)
	{
		System.out.println(b);			// Can call Static members(variable/methods)
		//System.out.println(a);		// ERROR - Can't call Bcoz main() also static member
		StatVarExample obj=new StatVarExample();
		System.out.println(obj.a);		// Need object to call instance()
	}

}
