package string;

public class StringEg2 {
	public static void main(String [] args)
	{
		//Immutable - fix
		
		String s = "Amey";
		s.concat("warekar");
		System.out.println(s);
		
		//To get output we need to store it in variable
		
		//Like this s = s.concat("warekar");
		
		//Mutable - Change
		
		StringBuilder sb = new StringBuilder("Amey");
		sb.append("Warekar");
		System.out.println(sb);
	}

}
