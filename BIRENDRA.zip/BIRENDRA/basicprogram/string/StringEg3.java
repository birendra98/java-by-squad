package string;

public class StringEg3 
{

	public static void main(String[] args) 
	{
		String s1 = new String("Amey");
		String s2 = new String("Amey");
		String s3 = new String("aMEY");
		
		//1 - equals() = Content
		System.out.println(s1.equals(s2));
		System.out.println(s1.equalsIgnoreCase(s3));
		
		//2 - == -> Memory location
		String s4 = "Amey";
		String s5 = "Amey";
		System.out.println(s4==s5);
		System.out.println(s1==s4);
		System.out.println(s2==s3);
		
		//3 - compareTo() = Number values of alphabet
		String s6 = "Harshal";
		System.out.println(s4.compareTo(s5));
		System.out.println(s1.compareToIgnoreCase(s3));
		System.out.println(s4.compareTo(s6));

	}

}
