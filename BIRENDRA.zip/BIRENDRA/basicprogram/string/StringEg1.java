package string;

public class StringEg1 
{

	public static void main(String[] args) 
	{
		//1 - new
		String s1 = new String();		//int i; //declare
		System.out.println(s1);
		
		String s2 = new String("Amey");	//int i = 2; //declare and initailization
		System.out.println(s2);
		
		String s3 = new String(s2);		//declare and initialization with predefined variables
		System.out.println(s3);
		
		char arr[] = new char[] {'A','M','E','Y'};
		String s4 = new String(arr);
		System.out.println(s4);
		
		
		// 2 - Literal
		String s5 = "Amey";
		System.out.println(s5);

	}

}
