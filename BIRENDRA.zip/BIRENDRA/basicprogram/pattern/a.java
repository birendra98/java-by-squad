package pattern;

public class a {
	public void m1(String b)
	{
		System.out.println("String");
	}
	public void m1(Object b)
	{
		System.out.println("Objet");
	}
	public static void main(String []args)
	{
		a obj = new a();
		obj.m1(null);
	}
}
