package abstraction_example;

abstract class absClass
{
	absClass()
	{
		this(10);
		System.out.println("Abstract class constructor");
	}
	absClass(int a)
	{
		System.out.println("Abstract class "+a);
	}
}

public class AbstractAccess extends absClass 
{
	AbstractAccess()
	{
		super();
		System.out.println("class constructor");
	}
	

	public static void main(String[] args) 
	{
		absClass obj = new AbstractAccess();

	}

}
