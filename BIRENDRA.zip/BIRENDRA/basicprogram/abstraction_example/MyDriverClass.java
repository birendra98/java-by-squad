package abstraction_example;

abstract class Home
{
	public void familyMember()
	{
		System.out.println("FAMILY MEMBERS");
	}
	
	public abstract void familyProperty();
}
public class MyDriverClass extends Home
{
	@Override
	public void familyProperty() 
	{
		System.out.println("20 Lakhs");
			
	}
	public static void main(String[] args) 
	{
		Home h = new MyDriverClass();
		h.familyProperty();
		h.familyMember();
	}	
}
