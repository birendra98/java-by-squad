package abstraction_example;

abstract class Car
{
	public void companyName()
	{
		System.out.println("Honda");
	}
	public abstract void engine();
	public abstract void features();
	public abstract void price();
}
abstract class HondaCitz extends Car
{

	@Override
	public void engine() {
		System.out.println("2000CC");
		
	}

	@Override
	public void features() 
	{
		System.out.println("xxxxxxxxx");
		
	}
	
}


public class MyDriverClass2 extends HondaCitz
{
	@Override
	public void price() 
	{
		System.out.println("2 Lakhs");
	}
	public static void main(String[] args) 
	{
		HondaCitz h = new MyDriverClass2();
		h.companyName();
		h.engine();
		h.features();
		h.price();
		
	}

}
