package abstraction_example;


abstract class Pvt
{
	private void m1()
	{
		System.out.println("Private");
	}
	public Pvt()
	{
		System.out.println("Constructor");
	}
	public Pvt(int a)
	{
		this();
		System.out.println(a);
	}
	
}
public class AbstractExp extends Pvt
{
	public AbstractExp()
	{
		super(20);
	}
	
	public static void main(String []args)
	{
		Pvt obj = new AbstractExp();
	}
	
}
