package userinput2;

public class NumberPattern {
	public static void main(String []args)
	{
	int cnt=0;
	for(int i=1; i<=5; i++)
	{
		cnt=i;
		for(int j=1; j<=i; j++)
		{
			System.out.print(cnt + " ");
			cnt=cnt+5;
		
		}
		System.out.println();
	}
	}

}
