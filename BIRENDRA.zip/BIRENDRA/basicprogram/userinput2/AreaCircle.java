package userinput2;

import java.util.Scanner;

public class AreaCircle {
	public static void main(String []args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter radius no ");
		float r=sc.nextFloat();
		double pi=3.14;
		double area=pi*r*r;
		System.out.println("Area of Circle is " + area);
		sc.close();
		
	}

}
