package userinput2;

import java.util.Scanner;

public class AreaSquare {
	public static void main(String []args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter square value");
		int sq=sc.nextInt();
		int area= sq*sq;
		System.out.println("Area of Circle is " + area);
		sc.close();
	}

}
