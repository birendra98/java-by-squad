package userinput2;

import java.util.Scanner;

public class CompoundInterest {
	public static void main(String []args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter P value");
		int p=sc.nextInt();
		System.out.println("Enter R Value");
		int r=sc.nextInt();
		System.out.println("Enter N value");
		int n=sc.nextInt();
		int ci=p*(1+(r/n));
		System.out.println("Compound Interest is " + ci);
	}

}
