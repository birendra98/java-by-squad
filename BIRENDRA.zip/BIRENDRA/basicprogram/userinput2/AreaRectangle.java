package userinput2;

import java.util.Scanner;

public class AreaRectangle {
	public static void main(String []args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter length value ");
		int l=sc.nextInt();
		System.out.println("Enter breadth value ");
		int b=sc.nextInt();
		int area=l*b;
		System.out.println("Area of Rectangle is " + area);
		sc.close();
	}

}
