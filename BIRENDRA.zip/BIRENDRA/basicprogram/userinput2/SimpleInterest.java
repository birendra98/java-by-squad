package userinput2;

import java.util.Scanner;

public class SimpleInterest {
	public static void main(String []args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter principal amount ");
		int pr=sc.nextInt();
		System.out.println("Enter N value");
		int n=sc.nextInt();
		System.out.println("Enter R value");
		int r=sc.nextInt();
		double si=(pr*n*r)/100;
		System.out.println("Simple Interest is " + si);
		sc.close();
	}

}
