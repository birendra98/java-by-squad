package userinput2;

import java.util.Scanner;

public class CircumferenceCircle {
	public static void main(String []args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter radius value");
		float r=sc.nextFloat();
		double pi=3.14;
		double cir =2*pi*r;
		System.out.println("Circumference of Circle is " + cir );
		sc.close();
	}

}
