package userinput2;

public class PrimeNumb {

	public static void main(String[] args) {
		for(int i = 1; i>10; i++)
		{
			if(i%2==0)
			{
				break;
			}
			else
			{
				System.out.println(i);
			}
		}

	}

}
