package userinput2;

public class SwapVariable {
	public static void main(String []args)
	{
		int a=10;
		int b=20;
		System.out.println("a is " + a);
		System.out.println("b is "+ b);
		int temp=b;
		b=a;
		a=temp;
		System.out.println("Swapped a is " + a);
		System.out.println("Swapped b is " + b);
	}

}
