package user_defined_datatype;

enum Day
{
	//CAPITAL
	MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY
}

public class EnumExm 
{
	Day day;
	
	EnumExm(Day d)
	{
		this.day=d;
	}
	
	public void enumMethod()
	{
		switch(day)
		{
		case MONDAY: System.out.println("This is Monday");
		break;
		case TUESDAY: System.out.println("This is Tuesday");
		break;
		default: System.out.println("Invalid");

		}
	}

	public static void main(String[] args) 
	{
		System.out.println(Day.SATURDAY);
		EnumExm obj = new EnumExm(Day.MONDAY);
		obj.enumMethod();
				
		

	}

}
