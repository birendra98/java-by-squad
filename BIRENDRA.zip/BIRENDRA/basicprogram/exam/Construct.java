package exam;

public class Construct {
	Construct()
	{
		System.out.println("Please Enter no");
	}
	Construct(int a)
	{
		System.out.println(a);
	}
	public static void main(String []args)
	{
		Construct obj=new Construct();
		Construct obj2=new Construct(20);
		
	}

}
