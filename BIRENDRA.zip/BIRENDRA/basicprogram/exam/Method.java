package exam;

public class Method {

}
