package userinput;

import java.util.Scanner;

public class HelloInformation {
	public static void main(String []args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("please enter information");
		System.out.println("Enter your Name");
		String a=sc.nextLine();
		System.out.println("Name : "+ a);
		System.out.println("Enter your Phone Number");
		int b=sc.nextInt();
		System.out.println("phone_no"+b);
		sc.close();
	}

}
