package userinput;

import java.util.Scanner;

public class Addition {
	public static void main(String []args)
	{
		int a, b, c;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your 1st Number");
		a=sc.nextInt();
		System.out.println("Enter your 2nd Number");
		b=sc.nextInt();
		c=a+b;
		System.out.println("Addition of " + a + " and " + b + " is " + c);
		sc.close();
		
	}

}
