package userinput;

import java.util.Scanner;

public class HelloBirendra {
	public static void main(String []args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter your Name: ");
		String input=sc.nextLine();
		System.out.println("Hello "+input);
		sc.close();
	}

}
