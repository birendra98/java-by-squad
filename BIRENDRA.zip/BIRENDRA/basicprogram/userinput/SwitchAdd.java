package userinput;

import java.util.Scanner;

public class SwitchAdd {
	public static void main(String []args) {
		int a,b,c,choose;
		Scanner sc=new Scanner(System.in);
		System.out.println("First No");
		a=sc.nextInt();
		System.out.println("Second No");
		b=sc.nextInt();
		System.out.println("choose 1 addition, choose 2 subtraction");
		choose=sc.nextInt();
		switch (choose)
		{
		case 1: 
		c=a+b;
		System.out.println("Addition"+c);
		break;
		
		case 2: 
		c=a-b;
		System.out.println("Subtration"+c);
		break;
		default: System.out.println("Invalid");
		sc.close();
		
		}
	}

}
