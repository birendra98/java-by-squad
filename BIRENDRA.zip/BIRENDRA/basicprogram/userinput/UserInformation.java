package userinput;

import java.util.Scanner;

public class UserInformation {
	public static void main(String []args)
	{
		String surname;
		int age;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Surname");
		surname=sc.next();
		System.out.println("Enter age");
		age=sc.nextInt();
		System.out.print("Your Information");
		System.out.println("Surname : " + surname);
		System.out.println("Age : " + age);
		sc.close();
	}

}
