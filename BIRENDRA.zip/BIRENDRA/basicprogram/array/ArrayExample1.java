package array;

public class ArrayExample1 {
	public static void main(String []args)
	{
		int arr[]= {10,20,30};
		System.out.println("Array Elements");
		System.out.println(arr[0]);
		System.out.println(arr[1]);
		System.out.println(arr[2]);
		
		int arrLength = arr.length;
		System.out.println(" Length " + arrLength);
		
		System.out.println(" Array elements with for ");
		for(int i=0; i<= arrLength; i++)
		{
			System.out.println(arr[i]);
		}
	}

}
