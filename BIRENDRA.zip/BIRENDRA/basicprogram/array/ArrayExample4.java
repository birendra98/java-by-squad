package array;

import java.util.Scanner;

public class ArrayExample4 {
	public static void main(String []args)
	{   
		int max=0;
		int arr[]= new int[3];
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Elements");
		for(int i=0; i<arr.length; i++)
		{
			arr[i]=sc.nextInt();
		}
		max=arr[0];
		
		System.out.println("Highest Array elements with for");
		for(int i=0; i<arr.length; i++)
		{
			if(arr[i] > max) 
			{
				max=arr[i];
			}
			
		}
		System.out.println(max);
	}
}
