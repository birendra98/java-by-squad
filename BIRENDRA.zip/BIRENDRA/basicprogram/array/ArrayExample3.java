package array;

import java.util.Scanner;

public class ArrayExample3 {
	public static void main(String []args)
	{         //Taking array size from user
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Array Size");
		int arrLength=sc.nextInt();
		int arr[] = new int[arrLength];
		
				// Taking array elements
		System.out.println("Enter Elements ");
		for(int i=0; i<arr.length; i++)
		{
			arr[i]=sc.nextInt();
		}
		
				// Print all array elements
		System.out.println("Array Elements with for");
		for(int i=0; i<arr.length; i++)
		{
			System.out.println(arr[i]);
		}
		sc.close();
	}

}
