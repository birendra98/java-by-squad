package basicprogram;

public class Basic {
	public static void main(String []args)
	{
		int a, b, c;
		a=5;
		b=4;
		c=a-b;
		System.out.println(c);
		boolean abc = false;
		System.out.println(!abc);
		
	}

}
