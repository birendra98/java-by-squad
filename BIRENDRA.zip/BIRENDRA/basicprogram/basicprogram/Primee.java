package basicprogram;

public class Primee {

	public static void main(String[] args) 
	{
		int s = 0;
		int e = 10;
		for(int i =s; i<=e; i++)
		{
			int c = 0;
			for(int d=2; d<i; d++)
			{
				if(i%d==0)
				{
					c++;
					break;
				}
			}
			if(c==0)
			{
				System.out.println(i+" Prime");
			}
		}

	}

}
