package encapsulation;

public class EmployeesInformM 
{

	public static void main(String[] args) 
	{
		EmployeeInform e = new EmployeeInform();
		e.setEmpId(10);
		e.setEmpName("Viren");
		System.out.println(e.getEmpId());
		System.out.println(e.getEmpName());
		
		

	}

}
