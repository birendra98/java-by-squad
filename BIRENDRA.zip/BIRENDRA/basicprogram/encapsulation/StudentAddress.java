package encapsulation;

public class StudentAddress 
{
	private String areaName;
	private int pinCode;
	public String getAreaName() {
		return areaName;
	}
	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}
	public int getPinCode() {
		return pinCode;
	}
	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}
	@Override
	public String toString() {
		return "StudentAddress [areaName=" + areaName + ", pinCode=" + pinCode + "]";
	}
	
	

}
