package encapsulation;

public class StudentInformMain 
{

	public static void main(String[] args) 
	{
		//Setter
		StudentInfo s = new StudentInfo();
		s.setStudId(10);
		s.setStudName("Viren");
		
		StudentAddress sa = new StudentAddress();
		sa.setAreaName("Mazagaon");
		sa.setPinCode(400010);
		
		s.setStudAddress(sa);
		
		//Getter
		
		System.out.println(s.getStudId());
		System.out.println(s.getStudName());
		System.out.println(s.getStudAddress());
		System.out.println(sa.getAreaName());
		System.out.println(sa.getPinCode());
		
		System.out.println(sa);
	}

}
