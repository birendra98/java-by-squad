package encapsulation;

public class StudentInfo 
{
	private int studId;
	private String studName;
	private StudentAddress studAddress;
	public int getStudId() {
		return studId;
	}
	public void setStudId(int studId) {
		this.studId = studId;
	}
	public String getStudName() {
		return studName;
	}
	public void setStudName(String studName) {
		this.studName = studName;
	}
	public StudentAddress getStudAddress() {
		return studAddress;
	}
	public void setStudAddress(StudentAddress studAddress) {
		this.studAddress = studAddress;
	}
	
	

}
