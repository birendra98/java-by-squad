package inheritance;

class HTCMobile
{
	public void ram()
	{
		System.out.println("8 gb");
	}
	public void rom()
	{
		System.out.println("64 gb");
	}
}
public class HTC10 extends HTCMobile
{
	public void rom()
	{
		System.out.println("128 gb");
	}
	
	String name="HTC 10";
	public void camera()
	{
		System.out.println("48mp");
	}
	
	public static void main(String[] args) 
	{
		/*HTC10 o = new HTC10();    			//static  
		 System.out.println("This is new "+o.name);
		 o.camera();		 */
		
		HTCMobile obj = new HTC10();		//Dynamic // In dynamic we call only override method
		obj.rom();							//updated values			
		//System.out.println("This is new "+obj.name);   // we cannot call method and variables
		// obj.camera();
		
	}

}
