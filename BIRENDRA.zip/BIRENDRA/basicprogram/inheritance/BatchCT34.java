package inheritance;

public class BatchCT34 extends SquadInfotech 
{
	String batchName = "CT-34";
	String time = " 1pm to 3pm";

	public static void main(String[] args) 
	{
		BatchCT34 obj = new BatchCT34();
		System.out.println(obj.batchName);
		System.out.println(obj.time);
		
		System.out.println(obj.name);
		obj.addressMumbai();
		
		
	}

}
