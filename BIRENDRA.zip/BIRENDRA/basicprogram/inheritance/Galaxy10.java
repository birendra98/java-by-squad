package inheritance;

class Samsung
{
	int processor = 800;
	int price = 10000;
	
}
public class Galaxy10 extends Samsung 
{
	int ram = 6;
	int modelPrice = 20000;

	public static void main(String[] args) 
	{
		Galaxy10 obj = new Galaxy10();
		System.out.println("Price " + obj.price);
		System.out.println("modelprice "+obj.modelPrice);
		System.out.println("processor "+obj.processor);
	}

}
