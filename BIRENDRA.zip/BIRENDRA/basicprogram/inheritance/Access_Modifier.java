package inheritance;

class Parent1
{
	private int a = 10;
	private void m1()
	{
		System.out.println("Parent 1-Method 1");
	}
	
	public int b = 10;
	public void m2()
	{
		System.out.println("Parent 1-Method 2");
	}
}

public class Access_Modifier extends Parent1
{
	protected int c = 10;
	protected void m3()
	{
		System.out.println("Parent 1-Method 1");
	}
	
	int d = 10;
	void m4()
	{
		System.out.println("Parent 1-Method 2");
	}	
	public static void main(String[] args) 
	{
		Access_Modifier obj =  new Access_Modifier();
		//obj.m1();						//Error The method m1()from the type Parent1 is not visible  
		//System.out.println(obj.a);		//Error The method m1()from the type Parent1 is not visible  
		obj.m2();
		System.out.println(obj.b);

	}

}
