package inheritance;

class SuperClass
{
	void m1()
	{
		System.out.println("Superclass Method");
	}
}
public class CastingExm extends SuperClass
{
	void m1()
	{
		System.out.println("Subclass Method");
	}
	public static void main(String []args)
	{
		SuperClass o = new SuperClass();		//static
		CastingExm o1 = new CastingExm();		//static
		
		SuperClass obj = new CastingExm();		//dynamic = Upcasting = Override
		obj.m1();
		
		//CastingExm obj1 = new SuperClass();		//Dynamic = Downcasting
		//Not Supported
		
		CastingExm obj2 = (CastingExm)o;	//Downcasting technique
		obj2.m1();
		//Excepting: ClassCastException will occur
	}
	

}
