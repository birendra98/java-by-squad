package inheritance;

class SquadInfotech
{
	String name = "SquadInfotech";
	public void addressMumbai()
	{
		System.out.println("ANDHERI, VASHI, NERUL");
	}
}
public class BatchCT33 extends SquadInfotech
{
	String batchName = "CT - 33";
	String time = "1pm to 3pm";
	
	public static void main(String[] args) 
	{
		BatchCT33 obj =  new BatchCT33();
		System.out.println(obj.batchName);
		System.out.println(obj.time);
		System.out.println(obj.name);
		obj.addressMumbai();
		
	}

}
