package inheritance;

class SuperClassExp
{
	int a=10;
	SuperClassExp()
	{
		System.out.println("SuperClass Constructor");
	}
	void m1()
	{
		System.out.println("Method of Superclass");
	}
}
public class SubClass extends SuperClassExp
{
	SubClass()
	{
		super();		//CALL Super Class CONSTRUCTOR //SUPER must be on 1st Line
		//this();		//cannot use both as both required to be on same line.
		System.out.println("Constructor1");
	}
	void m2()
	{
		super.m1();
		System.out.println(super.a);
		System.out.println("Method of Subclass");
	}

	public static void main(String[] args) 
	{
		SubClass obj = new SubClass();
		obj.m2();
	}

}
