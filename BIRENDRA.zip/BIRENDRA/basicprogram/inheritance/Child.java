package inheritance;

class Parent
{
	int parentA = 10;
	String variaA = "hello";
}

public class Child extends Parent
{
	int parentB = 20;
	public static void main(String[] args) 
	{
		System.out.println("This is Child class");
		Child obj = new Child();
		
		System.out.println(" A = " + obj.parentA);
		System.out.println(" B = " + obj.variaA);
		
		

	}

}
