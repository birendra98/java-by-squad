package inheritance;

class Honda
{
	public void engine()
	{
		System.out.println("150cc");
	}
}
public class Unicorn160 extends Honda 
{
	public void engine()
	{
		System.out.println("160cc");
	}
	
	public static void main(String[] args) 
	{
		Honda h = new Honda();				//static
		h.engine();
		
		Honda h1 = new Unicorn160();		//dynamic which override
		h1.engine();
	
	}

 
}
