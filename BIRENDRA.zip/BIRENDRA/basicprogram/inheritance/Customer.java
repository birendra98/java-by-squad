package inheritance;
class Hotel
{
	String hotelName = "Persion Darbar";
	public void hotel()
	{
		System.out.println("Address - Kurla");
	}
}
class Swiggy extends Hotel
{
	String deliveryBoy = "ID-Birendra";
	public void swiggyOffice()
	{
		System.out.println("Address - CST");
	}
}
public class Customer extends Swiggy
{
	int price = 500;

	public static void main(String[] args) 
	{
		Customer c = new Customer();
		System.out.println(c.price);
		System.out.println(c.deliveryBoy);
		System.out.println(c.hotelName);
		c.swiggyOffice();
		c.hotel();
		
	}

}
