package interface_exp;

interface Honda
{
	void name();
	interface Engine
	{
		void engineNo();
	}
}
public class NestedInterfaceExmp5 implements Honda.Engine
{
	@Override
	public void engineNo() 
	{
		System.out.println("150 CC");	
	}

	public static void main(String[] args) 
	{
		NestedInterfaceExmp5 obj = new NestedInterfaceExmp5();
		obj.engineNo();
	}

	

}
