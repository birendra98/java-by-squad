package interface_exp;

interface floorDesign
{
	void noOfFloors();
}
interface gateDesign extends floorDesign
{
	void noOfGates();
}
public class InterfaceExmp4 implements gateDesign
{

	@Override
	public void noOfFloors() 
	{
		System.out.println("7 floors");
		
	}

	@Override
	public void noOfGates() 
	{
		System.out.println("2 floors");
		
	}
	public static void main(String []args) 
	{
		InterfaceExmp4 obj = new InterfaceExmp4();
		obj.noOfFloors();
		obj.noOfGates();
		
	}
	
	
}