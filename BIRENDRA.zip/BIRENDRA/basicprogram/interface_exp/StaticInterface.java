package interface_exp;

interface si
{
	void m1();
	
	// from  "Java 1.8" we can add static and default methods
	
	// static
	
	public static void m2()
	{
		System.out.println("This is Interfac static method");
	}
	
	// default
	
	default void m3()
	{
		System.out.println("This is Interface Default method");
	}
}

public class StaticInterface implements si
{
	@Override
	public void m1() 
	{
		System.out.println("This is overridden method");
		
	}
	public static void main(String[] args) 
	{
		si.m2();
		StaticInterface obj = new StaticInterface();
		obj.m1();
		obj.m3();
	}


}
