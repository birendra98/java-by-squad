package interface_exp;

interface a
{
	void m1();
}

interface j
{
	void m1();
}

public class MultipleInheritance implements a, j 
{
	@Override
	public void m1()
	{
		System.out.println("This is Overridden method");
	}

	public static void main(String[] args) 
	{
		
		MultipleInheritance m = new MultipleInheritance();
		m.m1();
	}

}
