package interface_exp;

interface i
{
	//public abstract void m1();
	void m1();
	//public static final int a = 10;
	int a = 10;
}

public class Interface_ex1 implements i
{
	@Override
	public void m1() {
		System.out.println("Method1");
		
	}


	public static void main(String[] args) 
	{
		Interface_ex1 a = new Interface_ex1();
		//i a = new Interface_ex1(); //we can do upcasting
		a.m1();
	}

	
}
