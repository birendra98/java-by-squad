package innerclass;

class College
{
	int num = 25;
	public void college()
	{
		System.out.println("College Name");
	}
	
	static class Student
	{
		int id = 56;
		public void Info()
		{
			System.out.println("Andheri");
		}
	}
}


public class StaticInnerClassExm2 
{
	public static void main(String[] args) 
	{
		System.out.println("Outer Class");
		
		College obj = new College();
		System.out.println(obj.num);
		obj.college();
		
		System.out.println();
		
		System.out.println("Inner Class");
		
		College.Student i = new College.Student();
		System.out.println(i.id);
		i.Info();
		
		//
		new College.Student().Info();
		
		

	}

}
