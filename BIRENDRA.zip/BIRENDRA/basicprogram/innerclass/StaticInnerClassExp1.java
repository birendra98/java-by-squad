package innerclass;

class Car			//Outer Class
{
	public void carName()
	{
		System.out.println("Honda");
	}
	
	static class Engine 		//Static Inner Class
	{
		public void engineModel()
		{
			System.out.println("DS-25000");
		}
	}
	
}

public class StaticInnerClassExp1 
{

	public static void main(String[] args) 
	{
		Car obj = new Car();
		obj.carName();
		
		
		// Outer.Inner obj_name = new Outer.Inner();
		
		Car.Engine i = new Car.Engine();
		i.engineModel();
		
		// 3rd way of accessing method
		new Car.Engine().engineModel();
	}
}
