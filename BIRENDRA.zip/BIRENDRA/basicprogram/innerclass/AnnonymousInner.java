package innerclass;

abstract class Car1
{
	abstract void CarName();
}

abstract class Bike
{
	abstract void bikeName();
}
public class AnnonymousInner extends Car1
{
	@Override
	void CarName() 
	{
		System.out.println("BMW");
		
	}
	

	public static void main(String []args)
	{
		AnnonymousInner a  = new AnnonymousInner();
		a.CarName();
		
		
		(new Bike()
			{
			void bikeName()
			{
				System.out.println("Ninja");
			}}).bikeName();
	}

	
}
