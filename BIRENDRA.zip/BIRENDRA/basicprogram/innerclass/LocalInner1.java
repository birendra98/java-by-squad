package innerclass;



public class LocalInner1 
{
	int a = 10;
	public void m1()
	{
		System.out.println("Outer Method");
		
		class LocalInnerClass
		{
			public void innermethod()
			{
				System.out.println("Inner method");
				System.out.println("Outer class Variable a = " +  a);
			}
		}
		
		LocalInnerClass i = new LocalInnerClass();
		i.innermethod();
	}
	

	public static void main(String[] args) 
	{
		LocalInner1 o = new LocalInner1();
		o.m1();


	}

}
