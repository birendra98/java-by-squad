package innerclass;

abstract class StudentInfo
{
	abstract void studentInfo();
	abstract void classInfo();
}
public class AnnonymousClass2 
{

	public static void main(String[] args) 
	{
		StudentInfo obj = new StudentInfo()    //Annonymouse inner class
		{

			@Override
			void studentInfo() {
				System.out.println("Name - Viren");
			}

			@Override
			void classInfo() {
				System.out.println("Class : Squad");
				
			}
			
					
		};
		obj.studentInfo();
		obj.classInfo();
				
	}

}
