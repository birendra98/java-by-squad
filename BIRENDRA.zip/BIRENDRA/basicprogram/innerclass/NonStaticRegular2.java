package innerclass;


class Outer1
{
	public void m1()
	{
		System.out.println("Outer class Method");
		Outer1.Inner1 i = new Outer1.Inner1();			// fourth way of creating object 
														// and accessing inner class method
		i.m2();
	}
	class Inner1
	{
		public void m2()
		{
			System.out.println("Inner class Method");
		}
	}
}
public class NonStaticRegular2 {

	public static void main(String[] args) 
	{
		Outer1 o = new Outer1();
		o.m1();
		
		o.new Inner1().m2();	//3rd way

	}

}
