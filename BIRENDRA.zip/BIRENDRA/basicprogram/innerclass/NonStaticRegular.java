package innerclass;

// NonStatic - Regular Inner Class
class Company
{
	public void companyInfo()
	{
		System.out.println("TCS");
	}
	
	class Employee			// Regular Inner Class
	{
		public void employeeInfo()
		{
			System.out.println("AMEY");
		}
	}
}

public class NonStaticRegular 
{

	public static void main(String[] args) 
	{
		Company o = new Company();
		o.companyInfo();
		
		// Regular Inner Class object
		Company.Employee i = o.new Employee();
		i.employeeInfo();

	}

}
