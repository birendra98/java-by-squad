package innerclass;

abstract class Processor
{
	 abstract void processorName();
}

abstract class Camera
{
	abstract void cameraPixel();
}

public class AnnonymousInner5 extends Processor 
{
	@Override
	 void processorName() 
	 {
		System.out.println("Snapdragon 898");
	
	 }
	public static void main(String[] args) 
	{
		AnnonymousInner5 h = new AnnonymousInner5();
		h.processorName();
		
		Camera c = new Camera() 
		{

			@Override
			void cameraPixel() {
				System.out.println("108px Quad Camera Sony Sensor");
				
			}
			
			
		};
		c.cameraPixel();
	                                  
	}

	

}
