package innerclass;

public class College 
{
	String name = "Birendra";
	String address = "andheri";
	public void course()
	{
		class Courses
		{
			public void courseInfo()
			{
			String courseName = "Java";
			String courseFees = "1999rs";
			String courseDuration = "6 months";
			System.out.println("name - " + name);
			System.out.println("address - " + address);
			System.out.println("courseName - " + courseName);
			System.out.println("courseFees - " + courseFees);
			System.out.println("courseDuration - " + courseDuration);
			}
		}
		Courses i = new Courses();
		i.courseInfo();
	}

	public static void main(String[] args) 
	{
		College o = new College();
		o.course();
	
	}

}
