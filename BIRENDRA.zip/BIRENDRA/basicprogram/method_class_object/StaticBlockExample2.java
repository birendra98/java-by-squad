package method_class_object;

public class StaticBlockExample2 {
	int a=10;
	static int s= 50;
	static
	{
		System.out.println("Static Block");
		System.out.println(s);
	}
	{
		System.out.println("instance block");
		System.out.println(s);
		System.out.println(a);
	}
	public static void main(String []args)
	{
		StaticBlockExample2 obj = new StaticBlockExample2();
	}

}
