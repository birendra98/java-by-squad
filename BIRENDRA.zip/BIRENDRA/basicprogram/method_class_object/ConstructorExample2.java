package method_class_object;

public class ConstructorExample2 {
	ConstructorExample2()
	{
		System.out.println("zero constructor/non parameterised");
	}
	ConstructorExample2(int a)
	{
		System.out.println("parameterised"+ a);
	}
	ConstructorExample2(float a, float b)
	{
		System.out.println("parameterised a = ["+a+"] b = ["+b+"]");
	}
	public static void main(String []args)
	{
		System.out.println("main method");
		ConstructorExample2 obj1= new ConstructorExample2();
		ConstructorExample2 obj2= new ConstructorExample2(10);
		ConstructorExample2 obj3= new ConstructorExample2(10,20);
	}

}
