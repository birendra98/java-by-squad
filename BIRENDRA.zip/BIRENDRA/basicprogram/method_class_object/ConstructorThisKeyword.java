package method_class_object;

public class ConstructorThisKeyword {
	public ConstructorThisKeyword()
	{
		System.out.println("Cons overloading with this keyword");
	}
	public ConstructorThisKeyword(int a)
	{
		this();
		System.out.println("Cons overloading a ="+a);
	}
	public ConstructorThisKeyword(int a, int b)
	{
		this(100);
		System.out.println("Cons overloading a=" + a + ", b =" +b);
	}
	public ConstructorThisKeyword(int a, int b, int c)
	{
		this(10, 20);
		System.out.println("Cons overloading a = "+ a +", b = "+ b +" c = "+c);
	}
	public static void main(String []args)
	{
		ConstructorThisKeyword c3= new ConstructorThisKeyword(2,3,4);
	}

}
