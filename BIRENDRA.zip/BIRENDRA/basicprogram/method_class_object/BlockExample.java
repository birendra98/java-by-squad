package method_class_object;

public class BlockExample {
	{
		System.out.println("This is Block");
	}
	BlockExample()
	{
		System.out.println("This is Constructor");
	}
	public void m1()
	{
		System.out.println("Method");
	}
	public static void main(String []args)
	{
		BlockExample obj=new BlockExample();
		obj.m1();
	}

}
