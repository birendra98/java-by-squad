package method_class_object;

public class StaticBlockexample1 {
	static
	{
		System.out.println("Coder Technologies");
	}
	{
		System.out.println("Core-Java");
	}
	public StaticBlockexample1()
	{
		System.out.println("Batch CT-33");
	}

	public void m1(String a)
	{
		System.out.println("Name -"+a);
	}
	public static void main(String []args)
	{
		StaticBlockexample1 obj1 = new StaticBlockexample1();
				obj1.m1("Jay");
		StaticBlockexample1 obj2 = new StaticBlockexample1();
				obj2.m1("Bire");
		StaticBlockexample1 obj3 = new StaticBlockexample1();
				obj3.m1("harshad");
				
	
	}

}
