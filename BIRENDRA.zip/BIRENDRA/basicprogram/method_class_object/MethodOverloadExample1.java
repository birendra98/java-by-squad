package method_class_object;

public class MethodOverloadExample1 {
	public void area()
	{
		System.out.println("Calculation");
	}
	public void area(int a)
	{
		int c = a*a;
		System.out.println("Area of Square = " + c);
	}
	public void area(double a, double b)
	{
		double c= 0.5*a*b;
		System.out.println("Area of Triangle = " + c);
	}
	public void area(double a, double b, double c)
	{
		double d = (a*b*c)/100;
		System.out.println("Simple Interest = " + d);
	}
	public void area(int a, int b)
	{
		int c=a+b;
		System.out.println("Addition " + c);
	}
	public static void main(String []args)
	{
		System.out.println("Working main");
		MethodOverloadExample1 obj=new MethodOverloadExample1();
		obj.area();
		obj.area(10);
		obj.area(10.25, 20.25);
		obj.area(10, 20, 15);
		obj.area(10, 20);
	}

}
