package method_class_object;

public class MethodOverloadExample {
	public void areacalculation()
	{
		System.out.println("Calculation");
	}
	public void areacalculation(double a)
	{
		double c= 3.14*a*a;
		System.out.println("Area of circle = " + c);
	}
	public void areacalculation(int a, int b)
	{
		int c =a*b;
		System.out.println("Area of rectangle = " + c);
	}
	public static void main(String []args)
	{
		System.out.println("Working");
		MethodOverloadExample obj= new MethodOverloadExample();
		obj.areacalculation();
		obj.areacalculation(10);
		obj.areacalculation(20, 30);
		
	}

}
