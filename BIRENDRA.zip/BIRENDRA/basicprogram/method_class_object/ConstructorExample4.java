package method_class_object;

public class ConstructorExample4 {
		int length, breadth;
		ConstructorExample4(int l, int b)
		{
			int length=10;
			int breadth=20;
			this.length=l;
			this.breadth=b;
			System.out.println("local length = "+ length);
			System.out.println("local breadth = "+ breadth);
		}
		public static void main(String[] args)
		{
			System.out.println("main method");
			ConstructorExample4 obj=new ConstructorExample4(2,3);		
			System.out.println("global Length ="+obj.length);
			System.out.println("global breadth ="+obj.breadth);
		}

}



