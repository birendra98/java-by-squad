package method_class_object;

public class ConstructorExample3 {
	int length, breadth;
	ConstructorExample3(int l, int b)
	{
		length=l;
		breadth=b;
		System.out.println("length of                     rectangle = "+l);
		System.out.println("breadth of rectangle = "+b);
		
		int c= length*breadth;
		System.out.println("Area of rectangle = ["+c+"]");
	}
	public static void main(String[] args)
	{
		System.out.println("main method");
		ConstructorExample3 obj=new ConstructorExample3(2,3);		
		System.out.println(obj.length);
		System.out.println(obj.breadth);
	}

}
