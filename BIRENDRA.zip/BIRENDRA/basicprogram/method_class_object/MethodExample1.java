package method_class_object;

public class MethodExample1 {
	public void hello()
	{
		System.out.println("Hello I am noob");
	}
	public int add(int a, int b)
	{
		int c= a+b;
		return c;
	}
	public static void main(String []args)
	{
		MethodExample1 hi= new MethodExample1();
		hi.hello();
		hi.add(10,20);
	}

}
