package method_class_object;

public class StaticBlock {
	static
	{
		System.out.println("Static Block");
	}
	{
		System.out.println("instance Block");
	}
	StaticBlock()
	{
		System.out.println("Constructor");
	}
	public static void main(String []args)
	{
		StaticBlock obj = new StaticBlock();
	}

}
