package method_class_object;

public class InstanceOfExample {
	public static void main(String []args)
	{
		System.out.println("This is Animal Class");
		
		InstanceOfExample obj = new InstanceOfExample();
		InstanceOfExample a= new InstanceOfExample();
		InstanceOfExample b= null;
		
		System.out.println(obj instanceof InstanceOfExample);
		System.out.println(a instanceof InstanceOfExample);
		
		System.out.println(b instanceof InstanceOfExample);
	}

}
