package method_class_object;

public class ConstructorExample1 {
	ConstructorExample1()
	{
		System.out.println("This is Constructor Example 1");
	}
	public static void main(String []args)
	{
		ConstructorExample1 obj = new ConstructorExample1();
	}

}
