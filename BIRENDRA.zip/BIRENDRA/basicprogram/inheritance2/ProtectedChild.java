package inheritance2;

import inheritance.Access_Modifier;

public class ProtectedChild extends Access_Modifier
{
	public static void main(String[] args) 
	{
		ProtectedChild obj = new ProtectedChild();
		System.out.println(obj.c);
		obj.m3();
		//obj.m4();				//Error
	}

}
