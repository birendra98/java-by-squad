package conditionalflow;

public class NestedIfElse {
	public static void main(String []args)
	{
	int noOfDose=2;
	int noOfDays=15;
	int medicalInjection=2;
	if(noOfDose==2) // if(noOfDose ==2 && noOfDays >= 15)
	{
		if(noOfDays>=15)
		{
			System.out.println("Train pass available");
		}
		else
		{
			System.out.println("Train pass not available");
		}
	}
	else
	{
		if(medicalInjection==2)
		{
			System.out.println("Train pass available");
		}
		else
		{
			System.out.println("Train pass not available");
		}
	}

}
}
