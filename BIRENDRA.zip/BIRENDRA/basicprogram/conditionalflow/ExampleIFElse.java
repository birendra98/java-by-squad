package conditionalflow;

public class ExampleIFElse {
	public static void main(String []args)
	{
		int age;
		age=18;
		if (age >= 19)
		{
			System.out.println("Welcome to vote");
		}
		else
		{
			System.out.println("Not eligible for vote");
		}
	}

}
