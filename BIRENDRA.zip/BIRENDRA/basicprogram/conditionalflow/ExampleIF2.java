package conditionalflow;

public class ExampleIF2 {
	public static void main(String []args)
	{
		int age;
		age=35;
		if(age>65)
		{
			System.out.println("Vaccine Available");
		}
		System.out.println("End");
	}

}
