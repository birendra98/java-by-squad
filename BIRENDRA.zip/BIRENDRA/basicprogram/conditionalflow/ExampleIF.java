package conditionalflow;

public class ExampleIF {
	public static void main(String []args)
	{
		int age;
		age=40;
		if (age>18)
		{
			System.out.println("Valid Age");
		}
			System.out.println("End");
	}

}
