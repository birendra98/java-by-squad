package conditionalflow;

public class ExampleIfELSEif4 {
	public static void main(String []agrs)
	{
		int age;
		age=18;
		if(age > 18 && age < 45)
		{
			System.out.println("covaxin");
		}
		else if(age >= 45 && age < 65)
		{
			System.out.println("Covidshield");
		}
		else if(age>=65)
		{
			System.out.println("Both compulsory");
		}
		else
		{
			System.out.println("Not Valid");
		}
	}

}
