package conditionalflow;

public class ExampleIfelseif3 {

	public static void main(String[] args) {
		int mark;
		mark=100;
		if(mark >= 35 && mark < 60)
		{
			System.out.println("Pass");
		}
		else if(mark >=60 && mark < 90)
		{
			System.out.println("A");
		}
		else if(mark >= 90 && mark <= 100)
		{
			System.out.println("Merit");
		}
		else
		{
			System.out.println("Fail");
		}

	}

}
