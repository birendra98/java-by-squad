package conditionalflow;

public class Nestedif {
	public static void main(String []args)
	{
		int noOfDose=2;
		int noOfDays=12;
		if(noOfDose == 2)
		{
			if(noOfDays >= 15)
			{
				System.out.println("Train Pass Available");
			}
			System.out.println("Pass not avilable please complete 15 days");
		}
		else
		{
			System.out.println("Pass not avilable please complete 2 dose");
		}
	}

}
