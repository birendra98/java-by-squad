package conditionalflow;

public class ExampleIFElse2 {
	public static void main(String []args)
	{
		int a;
		a=20;
		if(a%2 == 0)
		{
			System.out.println("Even Number");
		}
		else
		{
			System.out.println("Odd");
		}
	}

}
