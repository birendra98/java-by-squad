package modifiers;

public class ModifiersExample1 {
	public static void main(String []args)
	{
		final int a=10;
		//a=20;
		System.out.println(a);
	}

}
