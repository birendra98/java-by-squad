package loopexample;

public class WhileExample2 {
	public static void main(String []args)
	{
		int i;
		i=20;
		while(i>=10)
		{
			System.out.println(i);
			i=i-1;
		}
	}
 
}
