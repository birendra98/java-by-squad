package loopexample;

public class ForLoopExample5 {
	public static void main(String []args)
	{
		for(int i=50;i<=100;i++)
		{
			int j=i%5;
			if(j==0)                      // (i%5==0)
			{
				System.out.println(i);
			}
		}
	}

}
