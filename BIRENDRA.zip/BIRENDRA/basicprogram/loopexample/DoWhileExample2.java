package loopexample;

public class DoWhileExample2 {
	public static void main(String []args)
	{
		int i;
		i=250;
		do
		{
			System.out.println(i);
			i=i-1;
		}
		while(i>=200);
	}

}
