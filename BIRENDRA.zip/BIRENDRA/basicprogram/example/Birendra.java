package example;

import java.util.Scanner;

//static import
import static java.lang.Math.pow;

public class Birendra {
	public static void main(String []args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter principal value");
		int p = sc.nextInt();
		System.out.println("Enter rate value");
		int r = sc.nextInt();
		System.out.println("Enter no of days");
		int n = sc.nextInt();
		System.out.println("Enter time value");
		int t = sc.nextInt();
		//int ci = (p*((1+(r/n))^(n*t)));
		double ci = p* pow(1+(r/n), n*t);
		System.out.println(ci);
		
	}
}