package exammmmm;

class OuterEX
{
	class Inner
	{
		public void m1()
		{
			System.out.println("Regular Inner");
		}
	}
}
public class RegularInner {

	public static void main(String[] args) {
		
		OuterEX obj = new OuterEX();
		OuterEX.Inner obj1= obj.new Inner();
		obj1.m1();

	}

}
