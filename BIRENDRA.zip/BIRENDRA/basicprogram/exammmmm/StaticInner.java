package exammmmm;


class Outer
{
	static class Inner
	{
		public void m1()
		{
			System.out.println("Static Inner Class");
		}
	}
}
public class StaticInner {

	public static void main(String[] args) 
	{
		Outer.Inner obj= new Outer.Inner();
		obj.m1();
		

	}

}
