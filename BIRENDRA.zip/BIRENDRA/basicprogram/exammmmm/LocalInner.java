package exammmmm;



class OuterPRE
{
	public void m1()
	{
		class Inner
		{
			void m2()
			{
				System.out.println("Local Inner");
			}
		}
		Inner obj =  new Inner();
		obj.m2();
		
		
	}
	
	
}
public class LocalInner {
	public static void main(String []args)
	{
		OuterPRE obj1 = new OuterPRE();
		obj1.m1();
	}

}
