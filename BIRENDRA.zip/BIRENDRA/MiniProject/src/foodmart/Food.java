package foodmart;

public class Food 
{	//Variables
	private int dishId, dishPrice;
	private String dishName, dishCategory;
	
	//constructor
	Food(int dishId, String dishName, String dishCategory, int dishPrice)
	{
		this.dishId	 = dishId;
		this.dishName = dishName;
		this.dishCategory = dishCategory;
		this.dishPrice = dishPrice;
	}
	
	//getter and setter generate
	public int getDishId() {
		return dishId;
	}
	public void setDishId(int dishId) {
		this.dishId = dishId;
	}
	public int getDishPrice() {
		return dishPrice;
	}
	public void setDishPrice(int dishPrice) {
		this.dishPrice = dishPrice;
	}
	public String getDishName() {
		return dishName;
	}
	public void setDishName(String dishName) {
		this.dishName = dishName;
	}
	public String getDishCategory() {
		return dishCategory;
	}
	public void setDishCategory(String dishCategory) {
		this.dishCategory = dishCategory;
	}
	
	//generate toString()
	@Override
	public String toString() {
		return "foodmenu [dishId=" + dishId + ", dishPrice=" + dishPrice + ", dishName=" + dishName + ", dishCategory="
				+ dishCategory + "]";
	}
	
	
	
	
	
	

}
