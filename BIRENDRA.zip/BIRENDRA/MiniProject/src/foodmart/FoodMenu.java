package foodmart;

import java.util.Scanner;

import objectarray_project.Books;

public class FoodMenu 
{

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		Food foods[] = new Food[10];
		int count = 0;
		int userId, userPwd=0;
		
		boolean logout = false;
		boolean adminLogin=false;
		boolean guestLogin=false;
		int lcount = 1;
		
		while(true)						//Login
		{
			if(lcount>0) {
			System.out.println("Welcome to Food Mart");
			System.out.println("Please enter user id");
			userId = sc.nextInt();
			System.out.println("Please enter user password");
			userPwd = sc.nextInt();
			if(userId==0000 && userPwd == 0000)
			{
				adminLogin= true;
				guestLogin= false;
			}
			else if(userId==1234 && userPwd== 1234)
			{
				adminLogin=false;
				guestLogin=true;
			}

			
		}
		while(true)						//menu // Nested while loop
		{
			lcount = 0;
			int dishId, dishPrice;
			String dishName, dishCategory;
				
				System.out.println();
				System.out.println("1 - Add dish ");
				System.out.println("2 - Add Multiple dish");
				System.out.println("3 - Update dish");
				System.out.println("4 - Search dish ");
				System.out.println("5 - Search multiple dish");
				System.out.println("6 - Delete dish");
				System.out.println("7 - Delete multiple dish");
				System.out.println("8 - show all");
				System.out.println("9 - EXIT");
				System.out.println("10 - Logout");
				System.out.println();
				System.out.println("Enter your choice from menu");
				int choice = sc.nextInt();
			
			switch(choice)
			{
				
			case 1:	
				if(adminLogin) {
				System.out.println("You select Add");
				System.out.println("Enter dish Id");
				dishId = sc.nextInt();
				
				System.out.println("Enter dish Name");
				dishName = sc.next();
				
				System.out.println("Enter dish Category");
				dishCategory = sc.next();
				
				System.out.println("Enter dish Price");
				dishPrice = sc.nextInt();
				foods[count]= new Food(dishId, dishName, dishCategory, dishPrice);				
				count++;
				
				System.out.println("Dish Added Successfully");
				}
				else
				{
					System.out.println("You dont have access");
				}
				break;
				
				
			case 2: if(adminLogin) {
				System.out.println("You select to Add Multiple dish");
				System.out.println("Enter How many dishes you have to add");
				int cot = sc.nextInt();
				for(int i = 0; i<cot; i++)
				{
					System.out.println("Enter dish Id");
					dishId = sc.nextInt();
				
					System.out.println("Enter dish Name");
					dishName = sc.next();
				
					System.out.println("Enter dish Category");
					dishCategory = sc.next();
				
					System.out.println("Enter dish Price");
					dishPrice = sc.nextInt();
					foods[count]= new Food(dishId, dishName, dishCategory, dishPrice);				
					count++;
				
					System.out.println("Dish Added Successfully");
				}
			}
			break;
				
			case 3: if(adminLogin) {
				System.out.println("You select Update");
				System.out.println("Please enter dish Id");
				dishId = sc.nextInt();
				
				for(int i = 0; i<=count; i++)
				{
					if(foods[i]!= null && foods[i].getDishId()==dishId)
					{
						System.out.println("Enter dish Name");
						dishName = sc.next();
						foods[i].setDishName(dishName);
						
						System.out.println("Enter dish Category");
						dishCategory = sc.next();
						foods[i].setDishCategory(dishCategory);
						
						System.out.println("Enter dish Price");
						dishPrice = sc.nextInt();
						foods[i].setDishPrice(dishPrice);
						
						System.out.println("Dish Updated Successfully");
					}
				}
			}
			break;
			
			case 4: if(adminLogin||guestLogin){
				System.out.println("You select search dish");
				System.out.println("Please Enter dish Id");
				dishId = sc.nextInt();
				
				for(int i = 0; i< count; i++)
				{
					if(foods[i]!=null && foods[i].getDishId()==dishId)
					{
						System.out.println(foods[i]);
					}
				}
			}
			break;
			
			case 5: if(adminLogin||guestLogin){
				System.out.println("Search multiple dish");
				System.out.println("How Many dish you have to search");
				int cot = sc.nextInt();
				for(int j = 0; j<cot; j++)
				{
					System.out.println("Please Enter dish Id");
					dishId = sc.nextInt();
					
					for(int i = 0; i<= count; i++)
					{
						if(foods[i]!=null && foods[i].getDishId()==dishId)
						{
							System.out.println(foods[i]);
						}
					}
				}
			}
			break;
			
			case 6: if(adminLogin){
				System.out.println("You select delete dish");
				System.out.println("Please Enter dish Id");
				dishId = sc.nextInt();
				
				for(int i = 0; i <= count; i++)
				{
					if(foods[i]!=null && foods[i].getDishId()==dishId) {
						foods[i]= null;
					}
				}
			}
			break;
			
			case 7 : if(adminLogin){
				System.out.println("You select Delete multiple dish");
				System.out.println(" How many delete dish");
				int cot = sc.nextInt();
				for(int j = 0; j<cot; j++)
				{
					System.out.println("Please Enter dish Id");
					dishId = sc.nextInt();
					
					for(int i = 0; i <= count; i++)
					{
						if(foods[i]!=null && foods[i].getDishId()==dishId) {
							foods[i]= null;
						}
					}
				}
			}
			break;
				
				
			case 8: if(adminLogin||guestLogin) {
				System.out.println("You select show all");
				for(int i = 0; i<=count; i++)
				{
					if(foods[i]!=null)
					{
						System.out.println(foods[i]);
					}
				}
			}
			break;
				
			case 9: if(adminLogin||guestLogin) {
				System.out.println("You select Exit");
				System.out.println("Exited Successfully");
				System.exit(0);
			}
				break;
				
			case 10:
				if(adminLogin || guestLogin)
				{
					System.out.println("Logout");
					adminLogin = false;
					guestLogin=false;
					logout=true;
					lcount=1;
				}
				else
				{
					System.out.println("Sorry ! you dont have access");
				}
				break;
				
			
			default: 
				System.out.println("Invalid choice");
				
			}
			if(logout||lcount==1)				//logout exited while loop menu 
			{
				break;
			}
			}
			
			
		}
	}

}
