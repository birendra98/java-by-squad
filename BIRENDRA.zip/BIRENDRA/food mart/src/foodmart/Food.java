package foodmart;

public class Food {
	

	}

}
